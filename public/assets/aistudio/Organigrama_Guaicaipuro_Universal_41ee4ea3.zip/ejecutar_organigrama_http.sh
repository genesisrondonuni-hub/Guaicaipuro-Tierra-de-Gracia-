#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Iniciando servidor HTTP ejecutable para el Organigrama de Guaicaipuro..."
python3 servidor_http_organigrama.py
