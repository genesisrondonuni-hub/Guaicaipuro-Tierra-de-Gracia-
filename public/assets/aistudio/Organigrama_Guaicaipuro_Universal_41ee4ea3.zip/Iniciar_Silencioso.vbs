Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
htmlPath = chr(34) & currentDir & "\Organigrama_Interactivo_Guaicaipuro.html" & chr(34)
WshShell.Run "cmd.exe /c start " & htmlPath, 0, False
