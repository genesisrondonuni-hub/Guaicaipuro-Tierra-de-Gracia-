#!/usr/bin/env python3
import http.server
import socketserver
import webbrowser
import os
import sys

PORT = 8080
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def run():
    os.chdir(DIRECTORY)
    try:
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            url = f"http://localhost:{PORT}/Organigrama_Interactivo_Guaicaipuro.html"
            print("==================================================================")
            print("  SERVIDOR HTTP EJECUTABLE • ORGANIGRAMA ALCALDÍA DE GUAICAIPURO  ")
            print("==================================================================")
            print(f"  Servidor iniciado exitosamente en: {url}")
            print("  Presiona CTRL+C en cualquier momento para detener el servidor.")
            print("==================================================================")
            try:
                webbrowser.open(url)
            except Exception:
                pass
            httpd.serve_forever()
    except OSError as e:
        if e.errno == 98: # Address already in use
            ALT_PORT = 8081
            with socketserver.TCPServer(("", ALT_PORT), Handler) as httpd:
                url = f"http://localhost:{ALT_PORT}/Organigrama_Interactivo_Guaicaipuro.html"
                print(f"Puerto {PORT} ocupado. Iniciado en puerto alternativo: {url}")
                try:
                    webbrowser.open(url)
                except Exception:
                    pass
                httpd.serve_forever()
        else:
            raise

if __name__ == "__main__":
    run()
