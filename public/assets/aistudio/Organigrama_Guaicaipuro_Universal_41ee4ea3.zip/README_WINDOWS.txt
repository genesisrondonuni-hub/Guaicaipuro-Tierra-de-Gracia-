===============================================================================
       ALCALDÍA DEL MUNICIPIO GUAICAIPURO - TIERRA DE GRACIA 2026
           PAQUETE EJECUTABLE PARA WINDOWS (100% PORTABLE)
===============================================================================

Este paquete contiene la aplicación interactiva del Organigrama Municipal con 
todos los cargos, métricas, policía, protección civil y educación liberal.

FORMAS DE EJECUCIÓN EN WINDOWS:
--------------------------------
1. MÉTODO 1 (EJECUTABLE NATIVO):
   Haga doble clic en "Organigrama_Guaicaipuro.exe".
   Se abrirá inmediatamente en su navegador predeterminado de forma silenciosa.

2. MÉTODO 2 (LANZADOR BATCH CON SERVIDOR LOCAL):
   Haga doble clic en "Iniciar_Organigrama_Windows.bat".
   Si tiene Python instalado, creará un servidor local http://localhost:8080 
   que habilita la opción de "Instalar como App en PC" vía Chrome/Edge.

3. MÉTODO 3 (EJECUCIÓN SILENCIOSA VBS):
   Haga doble clic en "Iniciar_Silencioso.vbs" para abrir sin ninguna ventana negra.

4. MÉTODO 4 (ACCESO DIRECTO):
   Haga doble clic en "Organigrama_Interactivo_Guaicaipuro.html".

-------------------------------------------------------------------------------
Alcaldía del Municipio Guaicaipuro • Plan Tierra de Gracia • Octubre 2026
===============================================================================
