@echo off
chcp 65001 >nul
title Organigrama Alcaldía de Guaicaipuro - Tierra de Gracia
color 0B

echo ===============================================================================
echo       ALCALDÍA DEL MUNICIPIO GUAICAIPURO - MODELO TIERRA DE GRACIA 2026
echo             ORGANIGRAMA INTERACTIVO Y ESTRUCTURA DE GOBIERNO
echo ===============================================================================
echo.
echo Iniciando aplicación en su navegador predeterminado...
echo.

:: Verificar si python está disponible para servidor HTTP local
python --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [OK] Python detectado. Iniciando servidor HTTP local optimizado...
    start "" "http://localhost:8080/Organigrama_Interactivo_Guaicaipuro.html"
    python -m http.server 8080
    exit
)

py --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [OK] Python Launcher detectado. Iniciando servidor local...
    start "" "http://localhost:8080/Organigrama_Interactivo_Guaicaipuro.html"
    py -m http.server 8080
    exit
)

echo [INFO] Abriendo directamente en el navegador del sistema...
start "" "%~dp0Organigrama_Interactivo_Guaicaipuro.html"
echo.
echo Organigrama abierto con éxito. Puede cerrar esta ventana.
timeout /t 3 >nul
exit
